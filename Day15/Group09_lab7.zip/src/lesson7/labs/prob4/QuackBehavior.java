package lesson7.labs.prob4;

public interface QuackBehavior {
	public default void quack() {
	   System.out.println("    Quacking");
	}

}
