package lesson7.labs.prob4;

public class MallarDuck extends Duck{

	@Override
	public void display() {
		System.out.println("    Display");
	}
	
}
