package lesson7.labs.prob1.partE;

public class D1 implements B , C {
	@Override
	public int method() {
		// TODO Auto-generated method stub
		
		return 0;
		
	}
}