package lesson7.labs.prob1.partE;

public interface C extends A {

	@Override
	 public default int method() {
		 return 1;
	 }
	
}
