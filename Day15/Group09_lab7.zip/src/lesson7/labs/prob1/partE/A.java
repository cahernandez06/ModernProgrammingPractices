package lesson7.labs.prob1.partE;

public interface   A {
	abstract public int method();
	
}
