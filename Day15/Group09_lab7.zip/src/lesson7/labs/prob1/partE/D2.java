package lesson7.labs.prob1.partE;

public interface D2  extends B , C {

	@Override
	default int method() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}	
