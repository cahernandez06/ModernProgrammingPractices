package Day13.Lab.prob4;

public class RedheadDuck extends Duck{

}
