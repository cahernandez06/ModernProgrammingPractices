package Day13.Lab.prob4;

public class MallarDuck extends Duck{

	@Override
	public void display() {
		System.out.println("    Display");
	}
	
}
